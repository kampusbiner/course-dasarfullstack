<?php

$username = $_POST['username'];
$password = $_POST['password'];

if($username == "siti@kampusbiner.com" && $password == "1234567890"){
  echo "ok";
}else{
  echo "fail";
}

?>